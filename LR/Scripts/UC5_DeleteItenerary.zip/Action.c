Action()
{

	lr_start_transaction("UC5_DeleteItenerary");
	
	web_set_sockets_option("SSL_VERSION", "AUTO");

	open_home_page();
	
	lr_think_time(5);
	
	login();
	
	lr_think_time(5);
	
	lr_start_transaction("see_all_itinerary");
	
		web_reg_find("Text/IC=User wants the intineraries.",
		LAST);

		web_reg_find("TextPfx/IC=<B>{userFirstName} {userLastName}",
		"TextSfx/IC= 's Flight Transaction Summary</B>",
		LAST);
	
		web_reg_save_param("flightID",
		"LB/IC=flightID\" value=\"",
		"RB/IC=\"",
		"Ord=1",
		LAST);
	
		web_add_auto_header("Sec-Fetch-User", 
			"?1");
	
		web_add_auto_header("Upgrade-Insecure-Requests", 
			"1");
		
		web_url("Itinerary Button", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
			"Snapshot=t3.inf", 
			"Mode=HTML", 
			LAST);

	lr_end_transaction("see_all_itinerary", LR_AUTO);
		
	lr_think_time(5);
	
	lr_start_transaction("delete_itenerary");

		web_reg_find("Fail=Found",
			"Text/IC={flightID}",
			LAST);
		
		web_add_header("Origin",
			"http://localhost:1080");
		
		web_submit_form("itinerary.pl", 
			"Snapshot=t4.inf", 
			ITEMDATA, 
			"Name=1", "Value=on", ENDITEM, 
			"Name=removeFlights.x", "Value=49", ENDITEM, 
			"Name=removeFlights.y", "Value=12", ENDITEM,
			LAST);
	
	lr_end_transaction("delete_itenerary", LR_AUTO);

//	lr_think_time(5);
	
//	logout();
	
	lr_end_transaction("UC5_DeleteItenerary", LR_AUTO);

	return 0;
}