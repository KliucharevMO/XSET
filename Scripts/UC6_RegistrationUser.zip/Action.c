Action()
{

	lr_start_transaction("UC6_RegistrationUser");

	open_home_page();
	
	lr_think_time(5);
	
	lr_start_transaction("press_sign_up_button");
	
		web_reg_find("Text/IC=First time registering? Please complete the form below.",
		LAST);
	
		web_set_sockets_option("SSL_VERSION", "AUTO");
	
		web_add_auto_header("Sec-Fetch-Dest", 
			"frame");
	
		web_revert_auto_header("Sec-Fetch-User");
	
		web_revert_auto_header("Upgrade-Insecure-Requests");
	
		web_add_auto_header("Sec-Fetch-Site", 
			"same-origin");
	
		web_url("sign up now", 
			"URL=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/WebTours/home.html", 
			"Snapshot=t2.inf", 
			"Mode=HTML", 
			LAST);
		
	lr_end_transaction("press_sign_up_button", LR_AUTO);
	
	lr_think_time(5);
		
	lr_start_transaction("create_customer_profile");
	
		web_reg_find("Text/IC=Thank you, <b>{prefixLogin}{symbol1}{symbol2}{symbol3}{symbol4}{symbol5}{symbol6}{symbol7}{symbol8}</b>, for registering",
		LAST);
	
		web_add_header("Origin", 
			"http://localhost:1080");
	
		web_add_auto_header("Sec-Fetch-User", 
			"?1");
	
		web_add_auto_header("Upgrade-Insecure-Requests", 
			"1");
	
		web_submit_data("login.pl", 
			"Action=http://localhost:1080/cgi-bin/login.pl", 
			"Method=POST", 
			"TargetFrame=info", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/login.pl?username=&password=&getInfo=true", 
			"Snapshot=t3.inf", 
			"Mode=HTML", 
			ITEMDATA, 
			"Name=username", "Value={prefixLogin}{symbol1}{symbol2}{symbol3}{symbol4}{symbol5}{symbol6}{symbol7}{symbol8}", ENDITEM, 
			"Name=password", "Value={prefixPass}{symbol5}{symbol4}{symbol3}{symbol2}{symbol1}", ENDITEM, 
			"Name=passwordConfirm", "Value={prefixPass}{symbol5}{symbol4}{symbol3}{symbol2}{symbol1}", ENDITEM, 
			"Name=firstName", "Value={prefName}{symbol8}{symbol7}{symbol6}{symbol5}{symbol4}", ENDITEM, 
			"Name=lastName", "Value={prefLastName}{symbol4}{symbol5}{symbol6}{symbol7}{symbol8}", ENDITEM, 
			"Name=address1", "Value={prefStreet}{symbol1}{symbol8}{symbol2}{symbol7}{symbol5}", ENDITEM, 
			"Name=address2", "Value={prefCity}{symbol3}{symbol6}{symbol4}{symbol5}", ENDITEM, 
			"Name=register.x", "Value=40", ENDITEM, 
			"Name=register.y", "Value=7", ENDITEM, 
			LAST);

	lr_end_transaction("create_customer_profile", LR_AUTO);

	lr_think_time(5);
	
	lr_start_transaction("confirm_registration");
	
		web_reg_find("Text/IC=Welcome, <b>{prefixLogin}{symbol1}{symbol2}{symbol3}{symbol4}{symbol5}{symbol6}{symbol7}{symbol8}</b>, to the Web Tours reservation pages.",
		LAST);

		web_revert_auto_header("Sec-Fetch-User");
	
		web_revert_auto_header("Upgrade-Insecure-Requests");
	
		lr_think_time(40);
	
		web_url("button_next.gif", 
			"URL=http://localhost:1080/cgi-bin/welcome.pl?page=menus", 
			"TargetFrame=body", 
			"Resource=0", 
			"RecContentType=text/html", 
			"Referer=http://localhost:1080/cgi-bin/login.pl", 
			"Snapshot=t4.inf", 
			"Mode=HTML", 
			LAST);
	
	lr_end_transaction("confirm_registration", LR_AUTO);
	
	lr_think_time(5);
	
	logout();
	
	lr_end_transaction("UC6_RegistrationUser", LR_AUTO);

	return 0;
}