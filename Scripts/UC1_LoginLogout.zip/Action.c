Action()
{
	
	lr_start_transaction("UC1_LoginLogout");
	
	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	open_home_page();
	
	lr_think_time(5);
	
	login();
	
	lr_think_time(5);
	
	logout();
	
	lr_end_transaction("UC1_LoginLogout", LR_AUTO);
	
	return 0;
}
